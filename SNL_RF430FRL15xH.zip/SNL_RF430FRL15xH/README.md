"MEDICAL-ICT CONVERGENCE HEALTHCARE-BASED APPLICATION" 1ST DRAFT
===========

## DEVELOPER:
1. YOUNGWOO OH
2. BUMSU KIM

## DEVELOPMENT PROCESSES:


## Install steps:
1. Download and install [Android Studio](https://developer.android.com/sdk/index.html)
2. In Android Studio, choose "Open and Existing Android Studio Project"
3. Select `/path/to/ti-sensor-app` and click "Choose"
4. Choose `Run>Run 'app'` or click the Play button in the toolbar to run the project