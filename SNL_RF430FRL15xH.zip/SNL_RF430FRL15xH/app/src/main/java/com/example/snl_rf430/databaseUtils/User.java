package com.example.snl_rf430.databaseUtils;

public class User
{

    public String uID;
    public String uNAME;
    public String uGENDER;
    public String uTIMESTAMP;
    public String uADC0;
    public String uADC1;
    public String uADC2;

    // GET
    public String getuID() {return uID;}
    public String getuNAME() {return uNAME;}
    public String getuGENDER() {return uGENDER;}
    public String getuTIMESTAMP() {return uTIMESTAMP;}
    public String getuADC0() {return uADC0;}
    public String getuADC1() {return uADC1;}
    public String getuADC2() {return uADC2;}

    // SET
    public void setuID(String uID) {this.uID = uID;}
    public void setuNAME(String uNAME) {this.uNAME = uNAME;}
    public void setuGENDER(String uGENDER) {this.uGENDER = uGENDER;}
    public void setuTIMESTAMP(String uTIMESTAMP) {this.uTIMESTAMP = uTIMESTAMP;}
    public void setuADC0(String uADC0) {this.uADC0 = uADC0;}
    public void setuADC1(String uADC1) {this.uADC1 = uADC1;}
    public void setuADC2(String uADC2) {this.uADC2 = uADC2;}
}
