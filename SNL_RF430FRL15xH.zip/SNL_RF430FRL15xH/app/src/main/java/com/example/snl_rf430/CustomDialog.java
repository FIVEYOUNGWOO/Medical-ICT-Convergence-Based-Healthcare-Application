package com.example.snl_rf430;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.annotation.NonNull;

public class CustomDialog extends Dialog implements View.OnClickListener
{
    private EditText dEditID;
    private EditText dEditName;

    private CheckBox dCheckMan;
    private CheckBox dCheckWoman;

    private Button dButtonOK;
    private Button dButtonNO;
    private Context context;

    private CustomDialogListener customDialogListener;

    public CustomDialog(@NonNull Context context)
    {
        super(context);
        this.context = context;
    }

    // Interface set
    interface CustomDialogListener
    {
        // 아래 부분의 입력 변수 조정해야할 수도 있음
        void onPositiveClicked(String id, String name, String gender);
        void onNegativeClicked();
    }

    // Initial
    public void setDialogListener(CustomDialogListener customDialogListener)
    {
        this.customDialogListener = customDialogListener;
    }

    @Override
    protected void onCreate(Bundle saveInstanceState)
    {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_custom_dialog);

        dEditID = (EditText) findViewById(R.id.dEditID);
        dEditName = (EditText) findViewById(R.id.dEditName);

        dCheckMan = (CheckBox) findViewById(R.id.dCheckMan);
        dCheckWoman = (CheckBox) findViewById(R.id.dCheckWoman);

        dButtonOK = (Button) findViewById(R.id.dButtonOK);
        dButtonNO = (Button) findViewById(R.id.dButtonNO);

        dButtonOK.setOnClickListener(this);
        dButtonNO.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.dButtonOK:
                String id = dEditID.getText().toString();
                String name = dEditName.getText().toString();
                String gender = "";

                if (dCheckMan.isChecked() && dCheckMan.getText().equals("남성"))
                {
                    gender = String.valueOf(dCheckMan.getText());
                }
                else if (dCheckWoman.isChecked() && dCheckWoman.getText().equals("여성"))
                {
                    gender = String.valueOf(dCheckWoman.getText());
                }

                customDialogListener.onPositiveClicked(id, name, gender);
                dismiss();
                break;

            case R.id.dButtonNO:
                cancel();
                break;
        }
    }

}
