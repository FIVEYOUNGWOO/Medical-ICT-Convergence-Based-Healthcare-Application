package com.example.snl_rf430.databaseUtils;

import android.provider.BaseColumns;

public final class DataBases
{
    public static final class CreateDB implements BaseColumns
    {
        public static final String USERID = "userid";
        public static final String USERNAME = "name";
        public static final String USERGENDER = "gender";
        public static final String TIMESTMAP = "timestamp";
        public static final String ADC0 = "adc0";
        public static final String ADC1 = "adc1";
        public static final String ADC2 = "adc2";
        public static final String _TABLENAME1 = "usertable";


        // We already defined value types in the Iso15693 Writing Activity <String>
        public static final String _CREATE1 = "create table if not exists "+_TABLENAME1+"("
                +_ID+" integer primary key autoincrement, "
                +USERID+" text not null , "
                +USERNAME+" text not null , "
                +USERGENDER+" text not null , "
                +TIMESTMAP+" text not null , "
                +ADC0+" text not null , "
                +ADC1+" text not null , "
                +ADC2+" text not null );";

    }
}
