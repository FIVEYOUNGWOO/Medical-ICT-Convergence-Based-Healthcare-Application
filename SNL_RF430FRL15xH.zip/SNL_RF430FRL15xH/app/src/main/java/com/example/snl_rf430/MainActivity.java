package com.example.snl_rf430;

import android.content.Intent;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.os.Vibrator;
import android.content.Context;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{

    // Share the user-input <USERID, USERNAME, USERGENDER>
    public static Context mContext;

    public String mUSERID;
    public String mUSERNAME;
    public String mUSERGENDER;
    public int mButtonCount = 0;

    // Make sure to use the AndroidDefaultButton
    Button mButtonReadTag;
    Button mButtonUserInfo;
    Button mButtonAccessDB;
    Button mButtonAppSetting;

    // Make sure to use the FloatingActionButton
    FloatingActionButton mButtonServices;
    FloatingActionButton mButtonAddUser;
    FloatingActionButton mButtonEmergency;
    Boolean isAllFabsVisible;

    @Override
    public void onCreate(Bundle saveInstanceState)
    {
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_main);

        // Generate pointer
        mContext = this;

        // Generate the custom dialog
        CustomDialog dialog = new CustomDialog(this);

        Toast.makeText(getApplicationContext(), "NFC 접근을 허용합니다.", Toast.LENGTH_SHORT).show();

        // Make sure to use the AndroidDefaultButton
        mButtonReadTag = (Button) findViewById(R.id.mButtonReadTag);
        mButtonUserInfo = (Button) findViewById(R.id.mButtonUserInfo);
        mButtonAccessDB = (Button) findViewById(R.id.mButtonAccessDB);
        mButtonAppSetting = (Button) findViewById(R.id.mButtonAppSetting);

        // Make sure to use the FloatingActionButton
        mButtonServices = findViewById(R.id.mButtonServices);
        mButtonAddUser = findViewById(R.id.mButtonAddUser);
        mButtonEmergency = findViewById(R.id.mButtonEmergency);

        // texts as GONE
        mButtonAddUser.setVisibility(View.GONE);
        mButtonEmergency.setVisibility(View.GONE);

        // make the boolean variable as false, as all the
        isAllFabsVisible = false;

        // FloatingActionButton Click handlers :: mButtonServices
        mButtonServices.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // alert the toast message
                Toast.makeText(getApplicationContext(), "부가 기능 확인...", Toast.LENGTH_SHORT).show();

                // display UI
                if (!isAllFabsVisible)
                {
                    mButtonAddUser.show();
                    mButtonEmergency.show();
                    isAllFabsVisible = true;
                }
                else
                {
                    mButtonAddUser.hide();
                    mButtonEmergency.hide();
                    isAllFabsVisible = false;
                }
            }
        });

        // FloatingActionButton Click handlers :: mButtonAddUser
        mButtonAddUser.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // alert the toast message
                Toast.makeText(getApplicationContext(), "등록하는 환자 정보를 입력해주세요.", Toast.LENGTH_SHORT).show();

                switch(v.getId())
                {
                    case R.id.mButtonAddUser:
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setDialogListener(new CustomDialog.CustomDialogListener()
                        {
                            @Override
                            public void onPositiveClicked(String id, String name, String gender)
                            {
                                mUSERID = id;
                                mUSERNAME = name;
                                mUSERGENDER = gender;
                                Toast.makeText(getApplicationContext(),
                                        "[" + mUSERID + "]" + ","
                                        + "[" + mUSERNAME + "]" + ","
                                        + "[" + mUSERGENDER + "]" + "등록 완료.", Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onNegativeClicked()
                            {
                                Toast.makeText(getApplicationContext(), "등록을 취소하였습니다.", Toast.LENGTH_SHORT).show();
                            }
                        });
                        dialog.show();
                        break;
                }
            }
        });

        // FloatingActionButton Click handlers :: mButtonEmergency
        mButtonEmergency.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // alert the toast message
                Toast.makeText(getApplicationContext(), "현재 구현되지 않은 기능입니다.", Toast.LENGTH_SHORT).show();
            }
        });


        // click the mButtonReadTag button
        mButtonReadTag.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // Conditions for sequential execution
                mButtonCount += 1;

                Toast.makeText(getApplicationContext(), "NFC 읽기 페이지로 이동", Toast.LENGTH_SHORT).show();

                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                vibrator.vibrate(300);

                // Go to Iso15693WriteTagActivity
                Intent intent = new Intent(getApplicationContext(), Iso15693WriteTagActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getApplicationContext().startActivity(intent);
            }
        });

        // click the mButtonUserInfo button
        mButtonUserInfo.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                // Conditions for sequential execution
                if (mButtonCount == 0)
                {
                    Toast.makeText(getApplicationContext(), "NFC 태깅을 먼저 수행하세요.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "조회 가능한 데이터가 존재합니다.", Toast.LENGTH_SHORT).show();

                    // Go to MainUserInfo
                    Intent intent = new Intent(getApplicationContext(), MainUserInfo.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getApplicationContext().startActivity(intent);
                }
            }
        });

        // click the mButtonAccessDB button
        mButtonAccessDB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if (mButtonCount == 0)
                {
                    Toast.makeText(getApplicationContext(), "NFC 태깅을 먼저 수행하세요.", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "데이터가 존재합니다.", Toast.LENGTH_SHORT).show();

                    // Go to MainAccessDB
                    Intent intent = new Intent(getApplicationContext(), MainAccessDB.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getApplicationContext().startActivity(intent);
                }
            }
        });

        // click the mButtonAppSetting button
        mButtonAppSetting.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(getApplicationContext(), "앱 설정 페이지로 이동", Toast.LENGTH_SHORT).show();

                // Go to MainAppSet
                Intent intent = new Intent(getApplicationContext(), MainAppSet.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getApplicationContext().startActivity(intent);
            }
        });
    }


    public void onResume()
    {
        super.onResume();

        Intent myintent = getIntent();
        if (myintent != null)
        {
            if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(myintent.getAction()) || NfcAdapter.ACTION_TECH_DISCOVERED.equals(myintent.getAction()) || NfcAdapter.ACTION_TAG_DISCOVERED.equals(myintent.getAction()))
            {
                Toast.makeText(getApplicationContext(), "NFC 접근이 탐지되었습니다.", Toast.LENGTH_SHORT).show();
                Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                vibrator.vibrate(300);

                setIntent(null);
                myintent.setClass(getApplicationContext(), Iso15693WriteTagActivity.class);
                myintent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getApplicationContext().startActivity(myintent);
            }
        }
    }

    @Override
    public void onBackPressed()
    {
        Toast.makeText(getApplicationContext(), "어플리케이션을 종료합니다.", Toast.LENGTH_LONG).show();
        ActivityCompat.finishAffinity(this);
        System.exit(0);
    }

    // ???
    @Override
    public void onClick(View view) {}

}
