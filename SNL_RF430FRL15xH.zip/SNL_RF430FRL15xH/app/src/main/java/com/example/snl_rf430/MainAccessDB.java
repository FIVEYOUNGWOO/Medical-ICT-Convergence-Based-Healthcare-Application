package com.example.snl_rf430;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

import com.example.snl_rf430.databaseUtils.DbOpenHelper;


public class MainAccessDB extends AppCompatActivity implements View.OnClickListener
{
    // For the database access functions
    Button mButtonInsert;
    Button mButtonUpdate;
    Button mButtonView;
    Button mButtonClose;

    // For find the user information
    EditText edit_id;
    EditText edit_name;
    CheckBox check_man;
    CheckBox check_woman;

    // For sorting the registered information
    CheckBox check_adc0;
    CheckBox check_adc1;
    CheckBox check_adc2;

    long nowIndex;
    String ID;
    String name;
    String gender = "";
    String sort = "userid";

    ArrayAdapter<String> arrayAdapter;

    static ArrayList<String> arrayIndex =  new ArrayList<String>();
    static ArrayList<String> arrayData = new ArrayList<String>();
    private DbOpenHelper mDbOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accessdb);

        // Connect to our UI
        mButtonInsert = (Button) findViewById(R.id.mButtonInsert);
        mButtonInsert.setOnClickListener(this);

        mButtonUpdate = (Button) findViewById(R.id.mButtonUpdate);
        mButtonUpdate.setOnClickListener(this);

        mButtonView = (Button) findViewById(R.id.mButtonView);
        mButtonView.setOnClickListener(this);

        mButtonClose = (Button) findViewById(R.id.mButtonClose);
        mButtonClose.setOnClickListener(this);

        edit_id = (EditText) findViewById(R.id.edit_id);
        edit_name = (EditText) findViewById(R.id.edit_name);

        check_man = (CheckBox) findViewById(R.id.check_man);
        check_man.setOnClickListener(this);

        check_woman = (CheckBox) findViewById(R.id.check_woman);
        check_woman.setOnClickListener(this);

        check_adc0 = (CheckBox) findViewById(R.id.check_adc0);
        check_adc0.setOnClickListener(this);

        check_adc1 = (CheckBox) findViewById(R.id.check_adc1);
        check_adc1.setOnClickListener(this);

        check_adc2 = (CheckBox) findViewById(R.id.check_adc2);
        check_adc2.setOnClickListener(this);

        arrayAdapter = new ArrayAdapter<String>(this, R.layout.custom_listview);
        ListView listView = (ListView) findViewById(R.id.db_list_view);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(onClickListener);
        listView.setOnItemLongClickListener(longClickListener);

        mDbOpenHelper = new DbOpenHelper(this);
        mDbOpenHelper.open();
        mDbOpenHelper.create();

        ///////////////////////////////////////////////////////////////////////////////////////////
        // If you need to remove the previous dataset
        // mDbOpenHelper.deleteAllColumns();
        ///////////////////////////////////////////////////////////////////////////////////////////

        check_adc0.setChecked(true);
        showDatabase(sort);

        // Automatic input of user information by using received empty values from MainActivity
        String sId = ((MainActivity)MainActivity.mContext).mUSERID;
        String sName = ((MainActivity)MainActivity.mContext).mUSERNAME;
        String sGender = ((MainActivity)MainActivity.mContext).mUSERGENDER;

        ID = sId;
        name = sName;
        gender = sGender;

        edit_id.setText(ID);
        edit_name.setText(name);

        if (sGender.trim().equals("남성"))
        {
            check_man.setChecked(true);
            check_woman.setChecked(false);
        }
        else if (sGender.trim().equals("여성"))
        {
            check_woman.setChecked(true);
            check_man.setChecked(false);
        }
        mButtonInsert.setEnabled(false);
        mButtonUpdate.setEnabled(false);
        mButtonView.setEnabled(true);
        mButtonClose.setEnabled(false);
    }

    public void setInsertMode()
    {
        edit_id.setText("");
        edit_name.setText("");

        check_man.setChecked(false);
        check_woman.setChecked(false);

        mButtonInsert.setEnabled(false);
        mButtonUpdate.setEnabled(false);
        mButtonView.setEnabled(true);
        mButtonClose.setEnabled(false);
    }

    private AdapterView.OnItemClickListener onClickListener = new AdapterView.OnItemClickListener()
    {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id)
        {
            Log.e("On Click", "position = " + position);
            nowIndex = Long.parseLong(arrayIndex.get(position));

            Log.e("On Click", "nowIndex = " + nowIndex);
            Log.e("On Click", "Data: " + arrayData.get(position));

            String[] tempData = arrayData.get(position).split("\\s+");
            Log.e("On Click", "Split Result = " + tempData);

            edit_id.setText(tempData[0].trim());
            edit_name.setText(tempData[1].trim());

            if(tempData[2].trim().equals("남성"))
            {
                check_man.setChecked(true);
                gender = "남성";
            }
            else if (tempData[2].trim().equals("여성"))
            {
                check_woman.setChecked(true);
                gender = "여성";
            }
            mButtonInsert.setEnabled(false);
            mButtonUpdate.setEnabled(false);
            mButtonView.setEnabled(true);
            mButtonClose.setEnabled(false);

            // For hide keyboard
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
       }
    };

    private AdapterView.OnItemLongClickListener longClickListener = new AdapterView.OnItemLongClickListener()
    {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
        {
            Log.d("Long Click", "position = " + position);
            nowIndex = Long.parseLong(arrayIndex.get(position));

            String[] nowData = arrayData.get(position).split("\\s+");

            // nowData[0] = id,
            // nowData[1] = name,
            // nowData[2] = gender,
            // nowData[3] = timestamp,
            // nowData[4] = ADC0,
            // nowData[5] = ADC1,
            // nowData[6] = ADC2
            String viewData = nowData[0] + ", " + nowData[1] + ", " + nowData[2] + ", " +
                              nowData[3] + ", " + nowData[4] + ", " + nowData[5] + ", " +
                              nowData[6];

            AlertDialog.Builder dialog = new AlertDialog.Builder(MainAccessDB.this);

            dialog.setTitle("데이터 삭제").setMessage("해당 데이터를 삭제 하시겠습니까?" + "\n" + viewData).setPositiveButton("네", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            Toast.makeText(MainAccessDB.this, "데이터를 삭제했습니다.", Toast.LENGTH_SHORT).show();
                            mDbOpenHelper.deleteColumn(nowIndex);
                            showDatabase(sort);
                            setInsertMode();
                        }
                    }).setNegativeButton("아니오", new DialogInterface.OnClickListener()
                    {
                        @Override
                        public void onClick(DialogInterface dialog, int which)
                        {
                            Toast.makeText(MainAccessDB.this, "삭제를 취소했습니다.", Toast.LENGTH_SHORT).show();
                            setInsertMode();
                        }
                    })
                    .create()
                    .show();
            return false;
        }
    };

    public void showDatabase(String sort)
    {
        Cursor iCursor = mDbOpenHelper.sortColumn(sort);
        Log.d("showDatabase", "DB Size: " + iCursor.getCount());
        arrayData.clear();
        arrayIndex.clear();

        while(iCursor.moveToNext())
        {
            // Occurred a lot of error lines, but we just ignore it.
            String tempIndex = iCursor.getString(iCursor.getColumnIndex("_id"));

            String tempID = iCursor.getString(iCursor.getColumnIndex("userid"));
            tempID = setTextLength(tempID,20);

            String tempName = iCursor.getString(iCursor.getColumnIndex("name"));
            tempName = setTextLength(tempName,20);

            String tempGender = iCursor.getString(iCursor.getColumnIndex("gender"));
            tempGender = setTextLength(tempGender,20);

            String tempTimestamp = iCursor.getString(iCursor.getColumnIndex("timestamp"));
            tempTimestamp = setTextLength(tempTimestamp, 20);

            String tempAdc0 = iCursor.getString(iCursor.getColumnIndex("adc0"));
            tempAdc0 = setTextLength(tempAdc0, 20);

            String tempAdc1 = iCursor.getString(iCursor.getColumnIndex("adc1"));
            tempAdc1 = setTextLength(tempAdc1, 20);

            String tempAdc2 = iCursor.getString(iCursor.getColumnIndex("adc2"));
            tempAdc2 = setTextLength(tempAdc2, 20);

            String Result = tempID + tempName + tempGender + tempTimestamp + tempAdc0 + tempAdc1 + tempAdc2;

            arrayData.add(Result);
            arrayIndex.add(tempIndex);
        }
        arrayAdapter.clear();
        arrayAdapter.addAll(arrayData);
        arrayAdapter.notifyDataSetChanged();
    }

    public String setTextLength(String text, int length)
    {
        if(text.length()<length)
        {
            int gap = length - text.length();
            for (int i=0; i<gap; i++)
            {
                text += " ";
            }
        }
        return text;
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            // for insert (just for functional test, we block the main project)
            case R.id.mButtonInsert:
                Toast.makeText(MainAccessDB.this, "정보를 추가하였습니다.", Toast.LENGTH_SHORT).show();
                ID = edit_id.getText().toString();
                name = edit_name.getText().toString();
                mDbOpenHelper.open();
                mDbOpenHelper.insertColumn(ID, name, gender, null, null, null, null);
                showDatabase(sort);
                setInsertMode();
                edit_id.requestFocus();
                edit_id.setCursorVisible(true);
                break;

            // For update (just for functional test, we block the main project)
            case R.id.mButtonUpdate:
                Toast.makeText(MainAccessDB.this, "정보를 갱신하였습니다.", Toast.LENGTH_SHORT).show();
                ID = edit_id.getText().toString();
                name = edit_name.getText().toString();
                ////////////////////////////////////////////////////////////////////////////////////////
                mDbOpenHelper.updateColumn(nowIndex,ID, name, gender, null, null, null, null);
                ////////////////////////////////////////////////////////////////////////////////////////
                showDatabase(sort);
                setInsertMode();
                edit_id.requestFocus();
                edit_id.setCursorVisible(true);
                break;

            // For view (select)
            case R.id.mButtonView:
                Toast.makeText(MainAccessDB.this, "저장된 정보를 가져옵니다.", Toast.LENGTH_SHORT).show();
                showDatabase(sort);
                break;

            // For delete
            case R.id.mButtonClose:
                Toast.makeText(MainAccessDB.this, "데이터베이스 연결을 차단합니다.", Toast.LENGTH_SHORT).show();
                mDbOpenHelper.close();
                break;

            // For check event
            case R.id.check_man:
                check_woman.setChecked(false);
                gender = "남성";
                break;

            case R.id.check_woman:
                check_man.setChecked(false);
                gender = "여성";
                break;

            // For sorting
            case R.id.check_adc0:
                Toast.makeText(MainAccessDB.this, "ADC0을 기준으로 정렬...", Toast.LENGTH_SHORT).show();
                check_adc1.setChecked(false);
                check_adc2.setChecked(false);
                sort = "ADC0";
                break;

            case R.id.check_adc1:
                Toast.makeText(MainAccessDB.this, "ADC1을 기준으로 정렬...", Toast.LENGTH_SHORT).show();
                check_adc0.setChecked(false);
                check_adc2.setChecked(false);
                sort = "ADC1";
                break;

            case R.id.check_adc2:
                Toast.makeText(MainAccessDB.this, "ADC2를 기준으로 정렬...", Toast.LENGTH_SHORT).show();
                check_adc0.setChecked(false);
                check_adc1.setChecked(false);
                sort = "ADC2";
                break;

        }
    }
}
