package com.example.snl_rf430.nfcUtils;

import android.content.Context;

public class HardwareManagerFactory
{
    public static HardwareManager getHardwareManager(Context ctx, int type)
    {
        switch(type)
        {
            case HardwareManager.HARDWARE_TYPE_NFCV:
                return new NfcVHardwareManager(ctx);
            default:
                break;
        }

        return null;
    }
}
