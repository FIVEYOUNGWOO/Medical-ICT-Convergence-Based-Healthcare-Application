package com.example.snl_rf430;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import androidx.appcompat.app.AppCompatActivity;

import com.example.snl_rf430.databaseUtils.DbOpenHelper;
import static com.example.snl_rf430.databaseUtils.DbOpenHelper.mDB;

import com.jjoe64.graphview.DefaultLabelFormatter;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

public class MainUserInfo extends AppCompatActivity implements View.OnClickListener
{

    // For access the DbOpenHelper class
    private DbOpenHelper mDbOpenHelper;

    // For the database access functions
    Button uButtonUpdate;
    Button uButtonClose;

    TextView uID;
    TextView uNAME;
    TextView uGENDER;

    TextView uADC0; // temperature
    TextView uADC1; // temporary
    TextView uADC2; // pressure

    //Graph var
    private LineGraphSeries<DataPoint> useriesADC0;
    private LineGraphSeries<DataPoint> useriesADC1;
    private LineGraphSeries<DataPoint> useriesADC2;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfo);

        // Connect to our UI
        uButtonUpdate = (Button) findViewById(R.id.uButtonUpdate);
        uButtonUpdate.setOnClickListener(this);

        uButtonClose = (Button) findViewById(R.id.uButtonClose);
        uButtonClose.setOnClickListener(this);

        uID = (TextView) findViewById(R.id.uID);
        uNAME = (TextView) findViewById(R.id.uNAME);
        uGENDER = (TextView) findViewById(R.id.uGENDER);

        uADC0 = (TextView) findViewById(R.id.uADC0); // Temperature (byte), @Color BLUE
        uADC1 = (TextView) findViewById(R.id.uADC1); // Temporary (byte), @Color GREEN
        uADC2 = (TextView) findViewById(R.id.uADC2); // Pressure (byte), @Color MAGENTA

        useriesADC0 = new LineGraphSeries<>();
        useriesADC1 = new LineGraphSeries<>();
        useriesADC2 = new LineGraphSeries<>();

        // For mapping color
        uADC0.setTextColor(Color.BLUE);
        uADC1.setTextColor(Color.GREEN);
        uADC2.setTextColor(Color.MAGENTA);

        useriesADC0.setColor(Color.BLUE);
        useriesADC1.setColor(Color.GREEN);
        useriesADC2.setColor(Color.MAGENTA);

        useriesADC0.setDrawDataPoints(true);
        useriesADC1.setDrawDataPoints(true);
        useriesADC2.setDrawDataPoints(true);

        //Graph initialization
        GraphView graph = (GraphView) findViewById(R.id.ugraph);
        graph.addSeries(useriesADC0);
        graph.addSeries(useriesADC1);
        graph.addSeries(useriesADC2);

        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(100);
        graph.getViewport().setScalable(true);  // enables horizontal scrolling
        graph.getViewport().setScalableY(true); // enables vertical scrolling
        graph.getViewport().setScalable(true);  // enables horizontal zooming and scaling
        graph.getViewport().setScalableY(true); // enables vertical zooming and scaling
        graph.getGridLabelRenderer().setTextSize(10f); // resize the graphview fontsize
        graph.getGridLabelRenderer().reloadStyles(); // enable resize

        // For replace the DefaultDataPoint(), x.getTime() convert to real values by using formatLabel>
        graph.getGridLabelRenderer().setLabelFormatter(new DefaultLabelFormatter()
        {
            @Override
            public String formatLabel(double value, boolean isValues)
            {
                if(isValues)
                {
                    // Divided in to dataformat and timeformat
                    Format DateForm = new SimpleDateFormat("yyyy-MM-dd");
                    Format TimeForm = new SimpleDateFormat("HH:mm:ss.SSS");

                    // Saved each divided timestamp <Date, Time>
                    String DatePart = DateForm.format(value);
                    String TimePart = TimeForm.format(value);

                    // Concat
                    String DisStamp = DatePart + "\n" + TimePart;

                    //return formatter.format(value);
                    return (DisStamp);
                }
                return super.formatLabel(value, isValues);
            }
        });

        // For Access the DbOpenHelper class
        mDbOpenHelper = new DbOpenHelper(this);
        mDbOpenHelper.open();
        mDbOpenHelper.create();

        uButtonClose.setEnabled(false);

        // For legend
        uADC0.setText("Temperature");
        uADC1.setText("Temporary");
        uADC2.setText("Pressure");

        // Automatic fullfill from the MainActivity
        uID.setText("환자 번호: " + ((MainActivity)MainActivity.mContext).mUSERID);
        uNAME.setText("환자 성함: " + ((MainActivity)MainActivity.mContext).mUSERNAME);
        uGENDER.setText("환자 성별: " + ((MainActivity)MainActivity.mContext).mUSERGENDER);
    }

    @Override
    public void onClick(View v)
    {
        switch (v.getId())
        {
            // For update (just for functional test, we block the main project)
            case R.id.uButtonUpdate:
                Toast.makeText(MainUserInfo.this, "저장된 DB 정보를 읽어옵니다.", Toast.LENGTH_SHORT).show();
                plots();
                break;

            // For delete
            case R.id.uButtonClose:
                Toast.makeText(MainUserInfo.this, "데이터베이스 연결을 종료합니다.", Toast.LENGTH_SHORT).show();
                mDbOpenHelper.close();
                break;
        }
    }

    // Try to read all the points from DB table
    public void plots()
    {
        Toast.makeText(MainUserInfo.this, "DB를 조회 중입니다.", Toast.LENGTH_SHORT).show();
        Cursor mCur = mDB.rawQuery( "SELECT * FROM usertable" + ";", null);

        // Check the number of line (points to plots)
        Integer count = mCur.getCount();
        Integer i = 0;

        // Plot the graph only if there are some data in the table
        if (count > 0)
        {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA);
            try
            {
                if (mCur.moveToFirst())
                {
                    do
                    {
                        Date date = format.parse(mCur.getString(4));
                        System.out.println("Date : " + date);
                        System.out.println("Date type : " + date.getClass());

                        uID.setText("환자 번호: " + mCur.getString(1));
                        uNAME.setText("환자 성함: " + mCur.getString(2));
                        uGENDER.setText("환자 성별: " + mCur.getString(3));

                        useriesADC0.appendData(new DataPoint(date, Double.parseDouble(mCur.getString(5))), true, 100);
                        useriesADC1.appendData(new DataPoint(date, Double.parseDouble(mCur.getString(6))), true, 100);
                        useriesADC2.appendData(new DataPoint(date, Double.parseDouble(mCur.getString(7))), true, 100);

                        i++;

                    } while(mCur.moveToNext());
                }
                mCur.close();
            }
            catch (ParseException  e)
            {
                Toast.makeText(MainUserInfo.this, "조회 가능한 데이터가 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }
    }
}
