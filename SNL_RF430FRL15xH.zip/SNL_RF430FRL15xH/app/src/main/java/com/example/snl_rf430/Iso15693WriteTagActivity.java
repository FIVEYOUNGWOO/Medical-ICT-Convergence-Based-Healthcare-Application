package com.example.snl_rf430;


import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.nfc.NfcAdapter;
import android.nfc.tech.NfcV;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.example.snl_rf430.nfcUtils.Iso15693;

import android.nfc.Tag;
import android.os.AsyncTask;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Formatter;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import android.widget.ProgressBar;
import com.example.snl_rf430.databaseUtils.DbOpenHelper;

// See Texas Instruments publication slau603a - RF430FRL15xH Firmware User's Guide, Section 7
// See the "RF430FRL152H_Util_V1_2_0F" software >> RF430FRL152H FW Register >> RegAddress & RegData

// Reference code output as below
// 02 00 14 00 B0 00 02 04 00 ADC1 = "09 58" PRESSURE = "09 58" 00 FF FF TEMPERATURE = "1E 60" 69 43 (OK)
// ADC1 = 09 58
// PRESSURE = 09 58
// TEMPERATURE = 1E 60
public class Iso15693WriteTagActivity extends AppCompatActivity
{
    // 0 Block [0000000000000000]
    byte RegisterBlock0[] = new byte[]
    {
            (byte) 0x01, // General Control Register
            (byte) 0x00, // Firmware Status Register
            (byte) 0x07, // Sensor Control Register
            (byte) 0x03, // Frequency Register
            (byte) 0x01, // Number of Passes Register
            (byte) 0x01, // Averaging Register
            (byte) 0x00, // Interrupt Control Register
            (byte) 0x40  // Error Control Register
    };

    // 1 Block [0000000000000000]
    byte RegisterBlock1[] = new byte[]
    {
            (byte) 0x00, // Reference-ADC1 Sensor Skip Count Register
            (byte) 0x00, // Thermistor-ADC2 Sensor Skip Count Register
            (byte) 0x00, // ADC0 Sensor Skip Count Register
            (byte) 0x00, // Internal Sensor Skip Count Register
            (byte) 0x00, // Digital Sensor 1 Skip Count Register
            (byte) 0x00, // Digital Sensor 2 Skip Count Register
            (byte) 0x00, // Digital Sensor 3 Skip Count Register
            (byte) 0x00  // Number of Blocks Received Register
    };

    // 2 Block [0000000000000000]
    byte RegisterBlock2[] = new byte[]
    {
            (byte) 0x19, // Reference-ADC1 Configuration Register
            (byte) 0x19, // Thermistor-ADC2 Sensor Configuration Register
            (byte) 0x18, // ADC0 Sensor Configuration Register
            (byte) 0x00, // Internal Sensor Configuration Register
            (byte) 0x00, // Initial Delay Period Setup Register
            (byte) 0x00, // JTAG Enable Password Register
            (byte) 0x00, (byte) 0x00 // Initial Delay Period Register
    };

    // 3 Block [0000000000000000]
    byte RegisterBlock3[] = new byte[]
    {
            (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, // Custom Timer Value Register
            (byte) 0x00, (byte) 0x00, // High Threshold Thermistor-ADC2 Sensor Register
            (byte) 0x00, (byte) 0x00  // Low Threshold ADC0 Sensor Register
    };

    // 4 Block [0000000000000000]
    byte RegisterBlock4[] = new byte[]
    {
            (byte) 0x00, (byte) 0x00, // Low Threshold Thermistor-ADC2 Sensor Register
            (byte) 0x00, (byte) 0x00, // High Threshold Thermistor-ADC2 Sensor Register
            (byte) 0x00, (byte) 0x00, // Low Threshold ADC0 Sensor Register
            (byte) 0x00, (byte) 0x00  // High Threshold ADC0 Sensor Register
    };

    // 5 Block [0000000000000000]
    byte RegisterBlock5[] = new byte[]
    {
            (byte) 0x00, (byte) 0x00, // Low Threshold Internal Temperature Sensor Register
            (byte) 0x00, (byte) 0x00, // High Threshold Internal Temperature Sensor Register
            (byte) 0x00, (byte) 0x00, // Low Threshold Digital1 Sensor Register
            (byte) 0x00, (byte) 0x00  // High Threshold Digital1 Sensor Register
    };

    // 6 Block [0000000000000000]
    byte RegisterBlock6[] = new byte[]
    {
            (byte) 0x00, (byte) 0x00, // Low Threshold Digital2 Sensor Register
            (byte) 0x00, (byte) 0x00, // High Threshold Digital2 Sensor Register
            (byte) 0x00, (byte) 0x00, // Low Threshold Digital3 Sensor Register
            (byte) 0x00, (byte) 0x00  // High Threshold Digital3 Sensor Register
    };

    // 7 Block [0000000000000000]
    byte RegisterBlock7[] = new byte[]
    {
            (byte) 0x00, // Reference or ADC1 Alarm Configuration Register
            (byte) 0x00, // Thermistor and ADC2 Alarm Configuration Register
            (byte) 0x00, // ADC0 Alarm Configuration Register
            (byte) 0x00, // Internal Alarm Configuration Register
            (byte) 0x00, // Digital 1 Alarm Configuration Register
            (byte) 0x00, // Digital 2 Alarm Configuration Register
            (byte) 0x00, // Digital 3 Alarm Configuration Register
            (byte) 0x00  // Logging Memory Size Register
    };


    private static final String TAG = Iso15693WriteTagActivity.class.getSimpleName();

    private NfcAdapter nfc;
    private PendingIntent mpendingIntent;

    // Share the user-input <USERID, USERNAME, USERGENDER>
    public static Context iContext;
    public String iUSERID;
    public String iUSERNAME;
    public String iUSERGENDER;
    public String iTIMESTMAP;
    public String iADC0;
    public String iADC1;
    public String iADC2;

    // For access the DbOpenHelper class
    private DbOpenHelper mDbOpenHelper;

    // For display packet counting
    private ProgressBar cntprogress;
    int pCnt = 0; // For progressbar
    int dCnt = 0; // For counting inserted RF430FRL15XH NFC tag data

    // For while() loop at run()
    int b_val = 1;

    // For display real-time plotting
    int Grp = 1;

    // For display timestamp value (<Date> type convert to <String>)
    String Time = "";

    // For display RF430FRL15XH communication status
    TextView nfcApp_status;

    TextView write_block_1;
    TextView write_block_2;
    TextView write_block_3;
    TextView write_block_4;
    TextView write_block_5;
    TextView write_block_6;
    TextView write_block_7;
    TextView write_block_8;
    TextView write_block_9;

    TextView receive_byte;
    TextView receive_block;
    TextView receive_value;
    TextView timestamp;
    TextView NumOfPkt;

    TextView ADC0; // temperature
    TextView ADC1; // temporary
    TextView ADC2; // pressure

    TextView cADC0; // color : @color BLUE
    TextView cADC1; // color : @color GREEN
    TextView cADC2; // color : @color MAGENTA

    //Graph var
    private final Handler mHandler = new Handler();
    private Runnable mTimer;
    private LineGraphSeries<DataPoint> seriesADC0, seriesADC1, seriesADC2;
    private double graphLastXValue = 5d;

    // For display parameters (This is used to represent the value obtained by running in the background)
    String DisCommandBlock1;
    String DisCommandBlock2;
    String DisCommandBlock3;
    String DisCommandBlock4;
    String DisCommandBlock5;
    String DisCommandBlock6;
    String DisCommandBlock7;
    String DisCommandBlock8;
    String DisCommandBlock9;
    String DisResult;
    String DisDataFromTag;

    // For display & convert received temperature value
    String DisTemperature = "0";

    // For display the received three sensor values
    String DisADC0 = "0";
    String DisADC1 = "0";
    String DisADC2 = "0";

    @Override
    public void onCreate(Bundle saveInstanceSate)
    {
        super.onCreate(saveInstanceSate);
        setContentView(R.layout.activity_iso15693);

        // Generate pointer
        iContext = this;

        // For Access the DbOpenHeler class
        mDbOpenHelper = new DbOpenHelper(this);
        mDbOpenHelper.open();
        mDbOpenHelper.create();

        // Connect to our UI : progress bar by using received NFC packet counting
        cntprogress = (ProgressBar) findViewById(R.id.cnt_progress);
        cntprogress.setProgress(0);

        // Connect to our UI
        nfcApp_status = (TextView) findViewById(R.id.nfcApp_status);

        write_block_1 = (TextView) findViewById(R.id.write_block_1);
        write_block_2 = (TextView) findViewById(R.id.write_block_2);
        write_block_3 = (TextView) findViewById(R.id.write_block_3);
        write_block_4 = (TextView) findViewById(R.id.write_block_4);
        write_block_5 = (TextView) findViewById(R.id.write_block_5);
        write_block_6 = (TextView) findViewById(R.id.write_block_6);
        write_block_7 = (TextView) findViewById(R.id.write_block_7);
        write_block_8 = (TextView) findViewById(R.id.write_block_8);
        write_block_9 = (TextView) findViewById(R.id.write_block_9);

        receive_byte = (TextView) findViewById(R.id.receive_byte);
        receive_block = (TextView) findViewById(R.id.receive_block);
        receive_value = (TextView) findViewById(R.id.receive_value);
        timestamp = (TextView) findViewById(R.id.timestamp);
        NumOfPkt = (TextView) findViewById(R.id.NumOfPkt);

        ADC0 = (TextView) findViewById(R.id.ADC0); // Temperature (byte)
        ADC1 = (TextView) findViewById(R.id.ADC1); // Temporary (byte)
        ADC2 = (TextView) findViewById(R.id.ADC2); // Pressure (byte)

        cADC0 = (TextView) findViewById(R.id.cADC0); // @Color BLUE
        cADC1 = (TextView) findViewById(R.id.cADC1); // @Color GREEN
        cADC2 = (TextView) findViewById(R.id.cADC2); // @Color MAGENTA

        seriesADC0 = new LineGraphSeries<>();
        seriesADC1 = new LineGraphSeries<>();
        seriesADC2 = new LineGraphSeries<>();

        // For mapping color <TEXTVIEW>
        cADC0.setTextColor(Color.BLUE);
        cADC1.setTextColor(Color.GREEN);
        cADC2.setTextColor(Color.MAGENTA);

        // For mapping color <Graph>
        seriesADC0.setColor(Color.BLUE);
        seriesADC1.setColor(Color.GREEN);
        seriesADC2.setColor(Color.MAGENTA);

        seriesADC0.setDrawDataPoints(true);
        seriesADC1.setDrawDataPoints(true);
        seriesADC2.setDrawDataPoints(true);

        //Graph initialization
        GraphView graph = (GraphView) findViewById(R.id.graph);
        graph.addSeries(seriesADC0);
        graph.addSeries(seriesADC1);
        graph.addSeries(seriesADC2);

        // Set of real-time graph includes zoom, and automatic X, Y axis scale
        graph.getViewport().setXAxisBoundsManual(true);
        graph.getViewport().setMinX(0);
        graph.getViewport().setMaxX(100);
        graph.getViewport().setScalable(true);  // enables horizontal scrolling
        graph.getViewport().setScalableY(true); // enables vertical scrolling
        graph.getViewport().setScalable(true);  // enables horizontal zooming and scaling
        graph.getViewport().setScalableY(true); // enables vertical zooming and scaling
        graph.getGridLabelRenderer().setTextSize(10f); // resize the graphview fontsize
        graph.getGridLabelRenderer().reloadStyles(); // enable resize

        nfc = NfcAdapter.getDefaultAdapter(this);

        if (!nfc.isEnabled())
        {
            nfcApp_status.setText("NFC를 사용할 수 없습니다.");
        }
        mpendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
    }


    // Added 10.09 (SUN)
    @Override
    protected void onNewIntent(Intent intent)
    {
        /**
         * This method gets called, when a new Intent gets associated with the current activity instance.
         * Instead of creating a new activity, onNewIntent will be called. For more information have a look
         * at the documentation.
         *
         * In our case this method gets called, when the user attaches a Tag to the device.
         */
        super.onNewIntent(intent);
        resolveIntent(intent);
    }

    // Modified at 10.09 (SUN)
    public void onResume()
    {
        super.onResume();

        if (nfc != null)
        {
            //Declare intent filters to handle the intents that you want to intercept.
            IntentFilter tech_intent = new IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED);
            IntentFilter[] intentFiltersArray = new IntentFilter[] {tech_intent, };

            //Set up an array of tag technologies that your application wants to handle
            String[][] techListsArray = new String[][] { new String[] { NfcV.class.getName() } };

            //Enable foreground dispatch to stop restart of app on detection
            nfc.enableForegroundDispatch(this, mpendingIntent, intentFiltersArray, techListsArray);
        }
        else
        {
            Toast.makeText(this, "NFC 속성이 존재하지 않습니다.", Toast.LENGTH_SHORT).show();
        }

        // Modified at 10.17 (MON)
        mTimer = new Runnable()
        {
            @Override
            public void run()
            {
                nfcApp_status.setText("백그라운드 NFC 모드가 실행중입니다.");

                // Add the received NFC packet
                cntprogress.setProgress(pCnt);

                // Show the readable NFC packet from the RF430FRL15XH tag
                List<String> NfcPacket = init_display();

                // If read NFC packet successfully, start sharing the received NFC information from the RF430FRL15XH
                if (dCnt > 0)
                {

                    if (!NfcPacket.isEmpty())
                    {
                        String userid = ((MainActivity)MainActivity.mContext).mUSERID;
                        String username = ((MainActivity)MainActivity.mContext).mUSERNAME;
                        String usergender = ((MainActivity)MainActivity.mContext).mUSERGENDER;

                        // Concat received 'USER' information and received 'RF430FRL15XH' information
                        iUSERID = userid;
                        iUSERNAME = username;
                        iUSERGENDER = usergender;
                        iTIMESTMAP = NfcPacket.get(0); // get timestamp [0]
                        iADC0 = NfcPacket.get(1); // get ADC0 [1]
                        iADC1 = NfcPacket.get(2); // get ADC1 [2]
                        iADC2 = NfcPacket.get(3); // get ADC2 [3]

                        System.out.println("read timestamp : " + iTIMESTMAP);
                        System.out.println("read ADC0 : " + iADC0);

                        // Insert 'USER' information and 'RF430FRL15XH' information to TABLE1
                        mDbOpenHelper.open();
                        mDbOpenHelper.insertColumn(iUSERID, iUSERNAME, iUSERGENDER, iTIMESTMAP, iADC0, iADC1, iADC2);

                        // Remove the previous 'USER' information and 'RF430FRL15XH' information
                        Iterator<String> iterator = NfcPacket.iterator();

                        while(iterator.hasNext())
                        {
                            String info = iterator.next();
                            iterator.remove();

                            if (NfcPacket.size() == 0)
                            {
                                System.out.println("DB에 저장된 값을 모두 출력하였습니다.");
                            }
                        }
                        dCnt -= 1;
                    }
                }

                if (Grp > 0)
                {
                    // Increasing number of sample
                    graphLastXValue += 1d;

                    // For legend
                    cADC0.setText("Temperature");
                    cADC1.setText("Temporary");
                    cADC2.setText("Pressure");

                    // Modified at 10.17 (MON)
                    // For real-time plotting
                    seriesADC0.appendData(new DataPoint(graphLastXValue, Float.parseFloat(DisADC0)), true, 100);
                    seriesADC1.appendData(new DataPoint(graphLastXValue, Float.parseFloat(DisADC1)), true, 100);
                    seriesADC2.appendData(new DataPoint(graphLastXValue, Float.parseFloat(DisADC2)), true, 100);
                }
                mHandler.postDelayed(this, 100);
            }
        };
        mHandler.postDelayed(mTimer, 300);
    }

    // Modified at 10.09 (SUN)
    @Override
    public void onPause()
    {
        mHandler.removeCallbacks(mTimer);
        super.onPause();

        if(nfc != null)
        {
            nfc.disableForegroundDispatch(this);
        }
    }

    // Modified at 10.09 (SUN), Communication and tag methods
    private Tag currentTag;
    private void resolveIntent(Intent intent)
    {
        String action = intent.getAction();

        //Check if the tag is ISO15693 and display message
        if (NfcAdapter.ACTION_TAG_DISCOVERED.equals(action) || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action))
        {
            nfcApp_status.setText("NFC를 탐지하였습니다.");
            Log.i("life cycle", "NfcAdapter.ACTION_TECH_DISCOVERED");

            currentTag = (Tag) intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);

            new NfcVReaderTask().execute(currentTag); // read ADC0, ADC1, ADC2 data in background
        }
    }

    // Modified at 10.09 (SUN)
    // Parsing function 1, 화면 표시용으로 사용중인데 아래가 맞는지 이게 맞는지 아직 모름...
    final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes)
    {
        char[] hexChars = new char[bytes.length * 3];
        for ( int j = 0; j < bytes.length; j++ )
        {
            int v = bytes[j] & 0xFF;
            hexChars[j * 3] = hexArray[v >>> 4];
            hexChars[j * 3 + 1] = hexArray[v & 0x0F];
            hexChars[j * 3 + 2] = ' ';
        }
        return new String(hexChars);
    }

    // Modified at 10.09 (SUN)
    // Parsing function 2, 현재 사용 안하는 중인데 위에랑 아래랑 뭔 차인질 모르겠어서 일단 보류함
    public static String bytesToHexString(byte[] bytes)
    {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        Formatter formatter = new Formatter(sb);

        for (byte b : bytes)
        {
            formatter.format("%02x", b);
        }
        return "0x" + sb.toString().toUpperCase();
    }

    /**
     *
     * Background task for reading the data. Do not block the UI thread while reading.
     *
     */
    private class NfcVReaderTask extends AsyncTask<Tag, Void, String>
    {
        @Override
        protected void onPostExecute(String result)
        {
            Log.i("Life cycle", "NFC thread start");
        }

        @Override
        protected String doInBackground(Tag... params)
        {
            Tag tag = params[0];
            readTagData(tag);
            return null;
        }
    }

    // Modified at 10.09 (SUN), read NFC430FRL15XH
    private void readTagData(Tag tag)
    {
        byte [] id = tag.getId();
        boolean techFound = false;

        // Checking for supporting techList
        for (String tech : tag.getTechList())
        {
            // Checking for NfcV protocol
            if (tech.equals(NfcV.class.getName()))
            {
                // Write and read from RF430FRL15XH NFC tag
                while(b_val > 0)
                {
                    techFound = true;

                    // Get an instance of NfcV for the given tag:
                    Iso15693 iso15693 = new Iso15693(currentTag);

                    byte[][] commandBlock = new byte[9][];

                    // Prepare sampling parameters
                    commandBlock[0] = iso15693.WriteSingleBlockCommand((byte) 1, RegisterBlock1);
                    commandBlock[1] = iso15693.WriteSingleBlockCommand((byte) 2, RegisterBlock2);
                    commandBlock[2] = iso15693.WriteSingleBlockCommand((byte) 3, RegisterBlock3);
                    commandBlock[3] = iso15693.WriteSingleBlockCommand((byte) 4, RegisterBlock4);
                    commandBlock[4] = iso15693.WriteSingleBlockCommand((byte) 5, RegisterBlock5);
                    commandBlock[5] = iso15693.WriteSingleBlockCommand((byte) 6, RegisterBlock6);
                    commandBlock[6] = iso15693.WriteSingleBlockCommand((byte) 7, RegisterBlock7);

                    // Trigger sampling
                    commandBlock[7] = iso15693.WriteSingleBlockCommand((byte) 0, RegisterBlock0);

                    // Read sample value
                    commandBlock[8] = iso15693.ReadSingleBlockCommand((byte) 9);

                    // Get response by using each write command
                    byte[] result = iso15693.executeCommandBlock(commandBlock);

                    // Can't receive status
                    if (null == result || (result[0] & Iso15693.ISO15693_ERROR_FLAG) != 0)
                    {
                        return;
                    }
                    // Can receive status
                    else
                    {
                        pCnt += 1;
                        dCnt += 1;
                        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                        vibrator.vibrate(100);
                    }

                    // Convert the received byte response to string
                     String dataFromTag = bytesToHexString(result);
                    // String dataFromTag = bytesToHex(result);

                    Log.i(TAG, dataFromTag + ' ' + dataFromTag.length());

                    if (20 > dataFromTag.length())
                    {
                        return;
                    }

                    // Conversion : Extract temperature in the received response from RF430FBL15XH transponder
                    double B_Value = 4330.0;
                    double R0_Value = 100000.0;
                    double T0_Value = 298.15;
                    double K0_Temp = 273.15;

                    long refValue = Long.parseLong(dataFromTag.substring(6,8).concat(dataFromTag.substring(4,6)),16);
                    long thermValue = Long.parseLong(dataFromTag.substring(10,12).concat(dataFromTag.substring(8,10)),16);

                    Double temperature = (((((thermValue * 0.9) / 16384.0) / 2.0) / 0.0000024) * 8738.13) / refValue;

                    temperature = (B_Value / (Math.log10(temperature / (R0_Value * Math.exp((-B_Value) /T0_Value))) / Math.log10(2.718))) - K0_Temp;

                    // temperature = (temperature * 9 / 5 + 32); // (°F)
                    temperature = (temperature - 32) * 5/9; // (°C)

                    // For display (Various data type convert to String)
                    DisCommandBlock1 = bytesToHexString(commandBlock[0]);
                    DisCommandBlock2 = bytesToHexString(commandBlock[1]);
                    DisCommandBlock3 = bytesToHexString(commandBlock[2]);
                    DisCommandBlock4 = bytesToHexString(commandBlock[3]);
                    DisCommandBlock5 = bytesToHexString(commandBlock[4]);
                    DisCommandBlock6 = bytesToHexString(commandBlock[5]);
                    DisCommandBlock7 = bytesToHexString(commandBlock[6]);
                    DisCommandBlock8 = bytesToHexString(commandBlock[7]);
                    DisCommandBlock9 = bytesToHexString(commandBlock[8]);

                    DisResult = bytesToHexString(result);
                    DisDataFromTag = dataFromTag;
                    DisTemperature = String.valueOf(temperature);
                }
            }
            else
            {
                nfcApp_status.setText("호환되지 않은 NFC가 접근하였습니다.");
                Toast.makeText(getApplicationContext(), "호환되지 않은 NFC가 접근하였습니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Background display and return <String>
    protected List<String> init_display()
    {
        // For return values
        List<String> StringList = new ArrayList<String>();

        double tmp_ADC0 = 1.0000;
        double tmp_ADC1 = 2.0000;
        double tmp_ADC2 = 3.0000;

        // For return values
        // List<String> StringList = new ArrayList<String>();
        String rTime;
        String rAdc0;
        String rAdc1;
        String rAdc2;

        // Include millisecond (ms)
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.KOREA);
        Time = date.format(new Date());

        // get number of packet, and timestamp information
        timestamp.setText("TIMESTAMP: " + Time);
        NumOfPkt.setText("NUMBER OF RECEIVED: " + pCnt);

        // show the write block 0~8
        write_block_1.setText("COMMAND BLOCK 1: " + DisCommandBlock1);
        write_block_2.setText("COMMAND BLOCK 2: " + DisCommandBlock2);
        write_block_3.setText("COMMAND BLOCK 3: " + DisCommandBlock3);
        write_block_4.setText("COMMAND BLOCK 4: " + DisCommandBlock4);
        write_block_5.setText("COMMAND BLOCK 5: " + DisCommandBlock5);
        write_block_6.setText("COMMAND BLOCK 6: " + DisCommandBlock6);
        write_block_7.setText("COMMAND BLOCK 7: " + DisCommandBlock7);
        write_block_8.setText("COMMAND BLOCK 8: " + DisCommandBlock8);
        write_block_9.setText("COMMAND BLOCK 9: " + DisCommandBlock9);

        // show the received response byte
        receive_byte.setText("RECEIVED BYTES: " + DisResult);
        receive_block.setText("RECEIVED DATAS: " + DisDataFromTag);
        receive_value.setText("RECEIVED VALUE: " + DisTemperature);

        // show ADC0, 1, 2 values (just display test)
        ADC0.setText("RECEIVED ADC0: " + tmp_ADC0);
        ADC1.setText("RECEIVED ADC1: " + tmp_ADC1);
        ADC2.setText("RECEIVED ADC2: " + tmp_ADC2);

        // show the real-time graph
        DisADC0 = String.valueOf(tmp_ADC0);
        DisADC1 = String.valueOf(tmp_ADC1);
        DisADC2 = String.valueOf(tmp_ADC2);

        // Overwrite return values
        rTime = Time;

        // Double type convert to String
        rAdc0 = String.valueOf(tmp_ADC0);
        rAdc1 = String.valueOf(tmp_ADC1);
        rAdc2 = String.valueOf(tmp_ADC2);

        // if read NFC packet successfully!!
        if (dCnt > 0)
        {
            // Append calculated values
            StringList.add(rTime);
            StringList.add(rAdc0);
            StringList.add(rAdc1);
            StringList.add(rAdc2);

            return StringList;
        }
        return null;
    }

    @Override
    protected void onDestroy() { super.onDestroy();}
}
